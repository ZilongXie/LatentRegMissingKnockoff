Rcpp::loadModule("hull", TRUE)
