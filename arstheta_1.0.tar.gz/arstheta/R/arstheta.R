# arstheta.R

#' arstheta
#'
#' @useDynLib arstheta, .registration = TRUE
#' @export ARS_Rwrapper
#' @export ThetaPosterior
#' @import Rcpp 

"_PACKAGE"

